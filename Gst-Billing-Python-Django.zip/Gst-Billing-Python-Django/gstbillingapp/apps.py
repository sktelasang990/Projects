from django.apps import AppConfig


class GstbillingappConfig(AppConfig):
    name = 'gstbillingapp'
